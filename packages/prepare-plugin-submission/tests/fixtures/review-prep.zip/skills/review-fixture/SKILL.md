---
name: review-fixture
description: Review a synthetic fixture record.
---
Read the supplied sample record and report its status.
