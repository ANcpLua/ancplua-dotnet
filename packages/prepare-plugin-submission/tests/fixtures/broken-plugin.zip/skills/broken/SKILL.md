Missing YAML frontmatter intentionally.
