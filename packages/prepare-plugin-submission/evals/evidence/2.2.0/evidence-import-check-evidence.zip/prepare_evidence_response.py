#!/usr/bin/env python3
"""Prepare structured evidence beside the answer, outside the session workspace."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
session = json.loads((root / "continued/submission.json").read_text())
work = Path(session["artifacts"]["session_workspace"])
assert not (work / "requirement-evidence").exists(), "Expected no automatic requirement-evidence imports before this follow-up"
inputs = root / "inputs"
inputs.mkdir(exist_ok=True)
assert work not in inputs.parents and inputs != work
source = zipfile.ZipFile(session["snapshot"]["archive"])
manifest = json.loads(source.read("plugin.json"))
review = manifest["extensions"]["com.openai"]["review"]["test_cases"]
observations = f"""# Observed offline preparation evidence

Target: {session['snapshot']['name']} {session['snapshot']['version']}.
Archive SHA-256: {session['snapshot']['package_sha256']}.
Intended host: ChatGPT. Session: {session['session_id']}.

The frozen archive contains {len(source.namelist())} files. Its manifest defines {len(review['positive'])} positive lookup review prompts and {len(review['negative'])} unsupported-deletion prompts. The source skill says to read a supplied sample record and report its status. The saved source-bound plan retains all eight remote prompts and a ninth supplied-record skill case. Source-defined goals, expected outcomes and boundaries are recorded in the session's prepared-materials.md and plan. Remote record data is not supplied; expected record content cannot be graded without a controlled oracle.

The package report states {session['snapshot']['package_report']['status']}, while the session has synthetic={str(session['synthetic']).lower()} and {len(session['host_rows'])} host evidence rows. Static package checks, document preparation, server/MCP execution, host behavior, recording playback, creator facts and portal stages remain separate. Nine host cases remain Not run. No target endpoint, target server, host installation/test, upload or portal action was performed. No creator declaration was invented. Host tests and recording remain deferred; seven official runtime/review gaps remain unverified.

This file records source inspection and preparation observations only. Its integrity does not prove runtime behavior, legal facts, actual host execution, recording availability or production readiness.
"""
observation_file = inputs / "observed-preparation.md"
observation_file.write_text(observations)
sha = hashlib.sha256(observation_file.read_bytes()).hexdigest()
rows = session["answers"]["requirement-review"]["decisions"]
file_ids = {"SS-PLAN-01", "SS-TEST-03", "SS-EVAL-02", "SS-REVIEW-03"}
source_ids = {"SS-POLICY-01": "plugin.json", "SS-POLICY-02": "mcp.json", "SS-SKILL-02": "skills/review-fixture/SKILL.md"}
for row in rows:
    row.pop("evidence_state", None)
    row.pop("evidence", None)
    if row["id"] in file_ids:
        row["evidence"] = {"file": "observed-preparation.md", "sha256": sha}
        row["evidence_reference"] = "Observed offline preparation in observed-preparation.md; actual runtime and host controls remain unverified."
    elif row["id"] in source_ids:
        name = source_ids[row["id"]]
        row["evidence"] = {"source_path": name, "sha256": hashlib.sha256(source.read(name)).hexdigest()}
        row["evidence_reference"] = "Frozen target source: " + name + "; source presence is not behavioral verification."
    else:
        row["evidence_reference"] = "Pending evidence: " + row["observed_result"]
response = inputs / "requirement-review.json"
response.write_text(json.dumps({"decisions": rows}, indent=2) + "\n")
record = {"session_workspace": str(work), "input_response": str(response), "original_external_evidence": str(observation_file),
          "external_file_sha256": sha, "manual_staging_performed": False, "pre_import_requirement_evidence_directory_absent": True,
          "file_evidence_rows": sorted(file_ids), "source_evidence_rows": source_ids, "row_statuses": {row["id"]:row["status"] for row in rows}}
(root / "evidence-input-manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"status":"Evidence inputs prepared outside the session", "row_count":len(rows), "file_rows":len(file_ids), "frozen_source_rows":len(source_ids), "manual_staging_performed":False, "response":str(response)}, indent=2))
