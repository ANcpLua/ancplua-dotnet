#!/usr/bin/env python3
"""Observe automatic evidence import/retention and keep behavioral gates unverified."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

root = Path(__file__).resolve().parent
phase, session_path = sys.argv[1], Path(sys.argv[2])
s = json.loads(session_path.read_text())
m = json.loads((root / "evidence-input-manifest.json").read_text())
rows = {row["id"]:row for row in s["answers"]["requirement-review"]["decisions"]}
work = Path(s["artifacts"]["session_workspace"])
digest = lambda data: hashlib.sha256(data).hexdigest()
expected_binding = {"content_sha256":s["snapshot"]["content_sha256"], "package_sha256":s["snapshot"]["package_sha256"],
                    "hosts":s["answers"]["hosts"]["hosts"], "test_plan_sha256":digest(json.dumps(s["answers"]["test-plan"], sort_keys=True, separators=(",", ":")).encode())}
archive = zipfile.ZipFile(s["snapshot"]["archive"])
file_rows = [rows[key] for key in m["file_evidence_rows"]]
source_rows = [rows[key] for key in m["source_evidence_rows"]]
checks = {
    "manual_staging_not_used": m["manual_staging_performed"] is False and m["pre_import_requirement_evidence_directory_absent"] is True,
    "file_evidence_copied_to_session_by_adapter": all((work / "requirement-evidence") in Path(row["evidence"]["file"]).parents and Path(row["evidence"]["file"]).is_file() for row in file_rows),
    "imported_file_hashes_match_supplied_observation": all(digest(Path(row["evidence"]["file"]).read_bytes()) == row["evidence"]["sha256"] == m["external_file_sha256"] for row in file_rows),
    "file_evidence_state_integrity_checked": all(row["evidence_state"] == "Imported artifact integrity checked" for row in file_rows),
    "source_evidence_paths_and_hashes_match_frozen_target": all(row["evidence"]["source_path"] == m["source_evidence_rows"][row["id"]] and digest(archive.read(row["evidence"]["source_path"])) == row["evidence"]["sha256"] for row in source_rows),
    "source_evidence_state_digest_checked": all(row["evidence_state"] == "Frozen source digest checked" for row in source_rows),
    "structured_evidence_bound_to_current_source_and_plan": all(row["evidence"]["binding"] == expected_binding for row in file_rows + source_rows),
    "plain_references_remain_unverified": all(row["evidence_state"] == "Reference only; not verified" for row in rows.values() if "evidence" not in row),
    "row_statuses_preserved_without_new_behavioral_passes": {key:row["status"] for key,row in rows.items()} == m["row_statuses"],
    "all_seven_official_gaps_remain_blocked": all(rows[key]["status"] == "Blocked" for key in ("SS-UI-03", "SS-EVENT-01", "SS-EVENT-02", "SS-POLICY-01", "SS-POLICY-02", "SS-REVIEW-01", "SS-REVIEW-03")),
    "no_host_capture_or_creator_portal_answers_created": s["host_rows"] == {} and not any(key in s["answers"] for key in ("creator-facts", "upload", "portal-validation", "submit-review", "review-decision", "publish", "review-materials")),
    "same_nine_case_chatgpt_plan_and_archive": len(s["answers"]["test-plan"]["cases"]) == 9 and s["answers"]["hosts"] == {"hosts":["chatgpt"]} and digest(Path(s["snapshot"]["archive"]).read_bytes()) == "1c16c6f92ef979d542d7def9cda6e1c73bcc45d9fba1bf69a90a959328fc4118",
}
if phase == "restored":
    bundle = root / "structured-evidence-checkpoint.zip"
    with zipfile.ZipFile(bundle) as z:
        paths = ["workspace/" + Path(row["evidence"]["file"]).relative_to(work).as_posix() for row in file_rows]
        checks["checkpoint_automatically_contains_imported_bytes"] = all(path in z.namelist() and digest(z.read(path)) == m["external_file_sha256"] for path in paths)
    checks["external_original_evidence_path_absent"] = not Path(m["original_external_evidence"]).exists()
    checks["fresh_restored_paths_rebased"] = all(str(root / "fresh-location/submission.files/requirement-evidence") in row["evidence"]["file"] for row in file_rows)
    checks["resumed_at_creator_facts_with_deferrals_intact"] = not s["paused"] and set(s["deferred"]) == {"host-tests", "review-materials", "requirement-review"} and json.loads((root / "logs/13-resume-fresh-location.stdout").read_text())["next"]["id"] == "creator-facts"
report = {"status":"Passed" if all(checks.values()) else "Failed", "scope":"Structured evidence import and checkpoint retention; target behavior is unverified", "phase":phase,
          "session":str(session_path), "revision":s["revision"], "manual_staging_performed":False,
          "file_evidence_rows":len(file_rows), "distinct_imported_files":len({row["evidence"]["file"] for row in file_rows}), "frozen_source_rows":len(source_rows), "checks":checks}
(root / ("automatic-evidence-" + phase + ".json")).write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
