#!/usr/bin/env python3
"""Record focused evidence-import commands and preserve full outputs."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parent
logs = root / "logs"
logs.mkdir(parents=True, exist_ok=True)
label, *argv = sys.argv[1:]
if not argv or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in label):
    raise SystemExit("usage: run_logged.py LABEL COMMAND [ARG ...]")
out, err = logs / (label + ".stdout"), logs / (label + ".stderr")
if out.exists() or err.exists():
    raise SystemExit("choose a new log label")
started = datetime.now(timezone.utc).isoformat()
result = subprocess.run(argv, cwd=root, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), capture_output=True)
out.write_bytes(result.stdout)
err.write_bytes(result.stderr)
record = dict(label=label, command=shlex.join(argv), argv=argv, cwd=str(root), environment={"PYTHONDONTWRITEBYTECODE":"1"},
              started_at=started, ended_at=datetime.now(timezone.utc).isoformat(), exit_code=result.returncode,
              stdout=str(out), stderr=str(err))
with (root / "commands.jsonl").open("a") as stream:
    stream.write(json.dumps(record) + "\n")
summary = None
try:
    data = json.loads(result.stdout)
    summary = {key: data[key] for key in ("status", "revision", "next", "simulation", "ready_for_human_portal", "submitted", "published", "session_path", "session_bundle") if key in data}
    if summary.get("next"):
        summary["next"] = {key:data["next"][key] for key in ("id", "actor", "question") if key in data["next"]}
    if not summary:
        summary = data
except (ValueError, UnicodeDecodeError):
    summary = result.stdout.decode(errors="replace")
print(json.dumps({"command": record["command"], "exit_code": result.returncode, "stdout":str(out), "stderr":str(err), "result":summary}, indent=2))
if result.stderr:
    sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
