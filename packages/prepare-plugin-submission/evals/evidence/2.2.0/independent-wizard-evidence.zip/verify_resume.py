#!/usr/bin/env python3
"""Verify the observed relocation without running target code or contacting it."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
old = json.loads((root / "original/submission.json").read_text())
new = json.loads((root / "relocated/submission.json").read_text())
resume_output = json.loads((root / "logs/21-resume-new-location.stdout").read_text())
new_work = root / "relocated/submission.files"
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks = {
    "session_identity_preserved": old["session_id"] == new["session_id"],
    "archive_hash_preserved": old["snapshot"]["package_sha256"] == new["snapshot"]["package_sha256"] == sha(new["snapshot"]["archive"]),
    "frozen_archive_bytes_preserved": Path(old["snapshot"]["archive"]).read_bytes() == Path(new["snapshot"]["archive"]).read_bytes(),
    "content_hash_preserved": old["snapshot"]["content_sha256"] == new["snapshot"]["content_sha256"],
    "test_plan_preserved": old["answers"]["test-plan"] == new["answers"]["test-plan"] and len(new["answers"]["test-plan"]["cases"]) == 9,
    "host_intent_preserved": old["answers"]["hosts"] == new["answers"]["hosts"] == {"hosts": ["chatgpt"]},
    "deferrals_preserved": old["deferred"] == new["deferred"] and set(new["deferred"]) == {"host-tests", "review-materials", "requirement-review"},
    "resumed_at_same_human_step": resume_output["next"]["id"] == "creator-facts" and resume_output["next"]["actor"] == "human" and not new["paused"],
    "source_is_relocated_frozen_archive": new["source_path"] == new["snapshot"]["archive"] and new_work in Path(new["source_path"]).parents,
    "artifacts_rebased_inside_relocated_workspace": all(new_work in Path(new["artifacts"][key]).parents for key in ("pack", "plan", "archive", "copy_fields")),
    "requirement_evidence_rebased_and_present": all(new_work in Path(row["evidence_reference"]).parents and Path(row["evidence_reference"]).is_file() for row in new["answers"]["requirement-review"]["decisions"]),
    "plan_bytes_preserved": sha(old["artifacts"]["plan"]) == sha(new["artifacts"]["plan"]),
    "no_host_evidence_fabricated": old["host_rows"] == new["host_rows"] == {},
    "all_host_cases_still_not_run": all(not row["satisfies_gate"] and row["status"] == "Not run" for row in json.loads((root / "logs/06-answer-test-plan.stdout").read_text())["next"]["coverage"]),
    "no_creator_or_portal_confirmations": not any(key in new["answers"] for key in ("creator-facts", "upload", "portal-validation", "submit-review", "review-decision", "publish")),
    "real_readiness_submission_publication_false": not any(resume_output[key] for key in ("ready_for_human_portal", "simulated_preparation_complete", "actual_host_execution_authenticated", "portal_actions_performed_by_tool", "submitted", "published")),
}
report = {"status": "Passed" if all(checks.values()) else "Failed", "scope": "Wizard export/restore and local state integrity only; no plugin host or server behavior was tested",
          "source_session": str(root / "original/submission.json"), "resumed_session": str(root / "relocated/submission.json"),
          "session_id": new["session_id"], "resumed_revision": new["revision"], "next_human_step": "creator-facts", "package_sha256": new["snapshot"]["package_sha256"], "checks": checks}
(root / "resume-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if all(checks.values()) else 1)
