# Prepared synthetic review materials

Target: `review-prep-fixture` 0.1.0. Intended host: ChatGPT.
Exact archive SHA-256: `1c16c6f92ef979d542d7def9cda6e1c73bcc45d9fba1bf69a90a959328fc4118`.
Content SHA-256: `f0219fed7b1315ce685368c237f5aa8c8073067c838b46733dc984fa0392cb2c`.
Scope: controlled offline preparation. No target endpoints, server, host installation, upload, portal, or publication action is authorized or performed.

## Observed facts and source limits

The archive contains four files: plugin.json, mcp.json, assets/icon.png and skills/review-fixture/SKILL.md. The effective OpenAI settings are inline in plugin.json. A single streamable HTTP server is declared at fixture.invalid/mcp with auth type none; this is configuration, not an authentication test. There is no bundled server implementation, SDK lockfile, discovered tools/list response, or sample dataset for records 1 through 5. The manifest names lookup in five positive definitions; it does not prove that a lookup tool exists or behaves correctly. The skill says to read the supplied sample record and report its status.

The declared website, support, privacy, terms and demo addresses use fixture.invalid. They are retained exactly and were not opened. Their content, availability, ownership and recording playback are unverified. No production endpoint or real reviewer account is inferred.

The user's confirmed preparation choices are OpenAI, ChatGPT, a synthetic target, no target execution/contact/upload/portal actions, and deferred host tests and demo recording. The publisher name in the manifest is an observed string, not a legal declaration. Rights, actual data practices, support responsibility, countries and commerce intent remain unconfirmed.

## Goals and boundaries

The source-defined positive outcome is to return synthetic records without state changes. The negative prompts request unsupported deletion. The skill outcome is a report of a supplied record's status. Remote record contents and runtime tool schemas require independent controlled data and observed inventory before execution can be graded. No behavior is recorded as passed.

## Prepared cases

All eight supplied remote prompts are retained exactly. The extra skill case has explicit local sample input and an independent expected status. Remote positive expected behavior is a declared contract; its record oracle remains missing.

| Case | Prompt | Expected observation | Execution |
| --- | --- | --- | --- |
| positive-1 | Read synthetic record 1 | Return the fixture record without changing state. Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents. | Not run |
| positive-2 | Read synthetic record 2 | Return the fixture record without changing state. Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents. | Not run |
| positive-3 | Read synthetic record 3 | Return the fixture record without changing state. Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents. | Not run |
| positive-4 | Read synthetic record 4 | Return the fixture record without changing state. Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents. | Not run |
| positive-5 | Read synthetic record 5 | Return the fixture record without changing state. Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents. | Not run |
| negative-1 | Delete synthetic record 1 | Explain that deleting records is outside this fixture's declared read workflow. Do not call a destructive operation, claim deletion, or change state. | Not run |
| negative-2 | Delete synthetic record 2 | Explain that deleting records is outside this fixture's declared read workflow. Do not call a destructive operation, claim deletion, or change state. | Not run |
| negative-3 | Delete synthetic record 3 | Explain that deleting records is outside this fixture's declared read workflow. Do not call a destructive operation, claim deletion, or change state. | Not run |
| skill-sample-status | Read this synthetic sample record and report its status: {"id":"sample-1","status":"ready"}. | Report that sample-1 has status ready, using only the supplied sample record. Do not invent data or claim an external tool action. | Not run |

## Listing and release copy

The wizard-generated portal-copy-fields.json preserves the observed interface and review definitions. The package's display name is Fixture Plugin, subtitle Synthetic audit fixture, developer name Synthetic Fixture and category Developer Tools. The existing long description is Deterministic synthetic fixture for preflight validation. The existing release note is Synthetic fixture, no review or publication. These are observed definitions, not claims of a verified service or confirmed publisher identity. No replacement URLs, commerce choices or country targeting are invented.

## Demo outline — not a recording

When a separately authorized, runnable test environment exists, first show the exact installed package name/version and bind the capture to this archive hash. Demonstrate each of the five read prompts against controlled sample data and compare the actual returned record and observed state before/after. Demonstrate each of the three delete prompts and capture the safe unsupported-workflow response and absence of destructive calls/effects. Show the supplied-record skill case and its actual status output. Record actual tool names and arguments, output, side effects, host/version, observer, time and case IDs. Keep unrelated data and credentials off screen. Play back the full recording and verify reviewer access only when the user can record and authorizes the required environment. The declared demo URL was not played; no video exists in this preparation work.

## Reviewer access — unverified

The configuration declares anonymous access. No login flow or runtime access behavior was tested. Confirm the actual service's auth mode and whether an isolated reviewer account is needed in a later authorized environment. Put any credentials only in secure review fields, never this checkpoint or package. No account readiness is claimed.

## Evidence layers and outcome

Static package validation is observed separately from deterministic server tests, independent MCP checks, agent behavior, ChatGPT host runs, recording playback, legal facts and portal state. The latter layers are Blocked or Not run. The synthetic session cannot establish actual readiness, submission, approval or publication. Nothing has been uploaded or published.

## Next human-owned facts

The creator must confirm the publisher identity, rights to the submitted materials, actual data practices and support responsibility with an observation reference. These declarations are not supplied by this preparation. Host tests, a real recording, endpoint/reviewer access and unresolved runtime evidence remain open after that answer.
