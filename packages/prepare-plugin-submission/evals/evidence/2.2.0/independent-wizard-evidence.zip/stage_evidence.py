#!/usr/bin/env python3
"""Keep the evidence referenced by the wizard inside its exportable workspace."""
import json
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
session = json.loads((root / "original/submission.json").read_text())
destination = Path(session["artifacts"]["session_workspace"]) / "preparation"
destination.mkdir(exist_ok=True)
for name in ("prepared-materials.md", "package-check.json", "package-check.html"):
    shutil.copyfile(root / name, destination / name)
shutil.copyfile(root / "logs/01-inspect-target.stdout", destination / "target-inspection.stdout")
shutil.copyfile(root / "responses/test-plan.json", destination / "test-plan-input.json")
review = json.loads((root / "responses/requirement-review.json").read_text())
for row in review["decisions"]:
    row["evidence_reference"] = str(destination / "prepared-materials.md")
(root / "responses/requirement-review-portable.json").write_text(json.dumps(review, indent=2) + "\n")
(destination / "requirement-review-input.json").write_text(json.dumps(review, indent=2) + "\n")
print(json.dumps({"preparation_evidence": str(destination), "requirements_referenced_inside_workspace": len(review["decisions"]),
                  "response": str(root / "responses/requirement-review-portable.json")}, indent=2))
