#!/usr/bin/env python3
"""Copy the current command trace and experience into an exportable session."""
import json
from pathlib import Path
import shutil
import sys

root = Path(__file__).resolve().parent
session = json.loads(Path(sys.argv[1]).read_text())
destination = Path(session["artifacts"]["session_workspace"]) / "preparation"
destination.mkdir(exist_ok=True)
for name in ("commands.jsonl", "wizard-experience.md", "source-retrieval.md", "forward-report.md"):
    shutil.copyfile(root / name, destination / name)
if (root / "resume-verification.json").is_file():
    shutil.copyfile(root / "resume-verification.json", destination / "resume-verification.json")
shutil.copytree(root / "logs", destination / "command-logs", dirs_exist_ok=True)
print(json.dumps({"snapshot": str(destination), "commands_preserved": len((root / "commands.jsonl").read_text().splitlines()), "reporting_only": True}, indent=2))
