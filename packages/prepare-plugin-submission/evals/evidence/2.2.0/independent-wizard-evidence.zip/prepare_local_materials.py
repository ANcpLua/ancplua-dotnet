#!/usr/bin/env python3
"""Draft evidence-bound materials without executing the target or contacting it."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SESSION = ROOT / "original/submission.json"
state = json.loads(SESSION.read_text())
snapshot = state["snapshot"]
facts = snapshot["facts"]
sha = snapshot["package_sha256"]
cases = []
for index, row in enumerate(snapshot["review_cases"], 1):
    positive = row["kind"] == "positive"
    cases.append({
        "id": ("positive-" if positive else "negative-") + str(index if positive else index - 5),
        "prompt": row["prompt"],
        "expected": row["expected_behavior"] + " Compare the returned record with controlled sample data supplied by the test owner; do not invent absent record contents."
                    if positive else "Explain that deleting records is outside this fixture's declared read workflow. Do not call a destructive operation, claim deletion, or change state.",
    })
cases.append({"id": "skill-sample-status", "prompt": 'Read this synthetic sample record and report its status: {"id":"sample-1","status":"ready"}.',
              "expected": "Report that sample-1 has status ready, using only the supplied sample record. Do not invent data or claim an external tool action."})
responses = ROOT / "responses"
responses.mkdir(exist_ok=True)
(responses / "test-plan.json").write_text(json.dumps({"cases": cases}, indent=2) + "\n")
table = "\n".join("| " + c["id"] + " | " + c["prompt"].replace("|", "\\|") + " | " + c["expected"].replace("|", "\\|") + " | Not run |" for c in cases)
intro = f"""# Prepared synthetic review materials

Target: `{snapshot['name']}` {snapshot['version']}. Intended host: ChatGPT.
Exact archive SHA-256: `{sha}`.
Content SHA-256: `{snapshot['content_sha256']}`.
Scope: controlled offline preparation. No target endpoints, server, host installation, upload, portal, or publication action is authorized or performed.

## Observed facts and source limits

The archive contains four files: plugin.json, mcp.json, assets/icon.png and skills/review-fixture/SKILL.md. The effective OpenAI settings are inline in plugin.json. A single streamable HTTP server is declared at fixture.invalid/mcp with auth type none; this is configuration, not an authentication test. There is no bundled server implementation, SDK lockfile, discovered tools/list response, or sample dataset for records 1 through 5. The manifest names lookup in five positive definitions; it does not prove that a lookup tool exists or behaves correctly. The skill says to read the supplied sample record and report its status.

The declared website, support, privacy, terms and demo addresses use fixture.invalid. They are retained exactly and were not opened. Their content, availability, ownership and recording playback are unverified. No production endpoint or real reviewer account is inferred.

The user's confirmed preparation choices are OpenAI, ChatGPT, a synthetic target, no target execution/contact/upload/portal actions, and deferred host tests and demo recording. The publisher name in the manifest is an observed string, not a legal declaration. Rights, actual data practices, support responsibility, countries and commerce intent remain unconfirmed.

## Goals and boundaries

The source-defined positive outcome is to return synthetic records without state changes. The negative prompts request unsupported deletion. The skill outcome is a report of a supplied record's status. Remote record contents and runtime tool schemas require independent controlled data and observed inventory before execution can be graded. No behavior is recorded as passed.

## Prepared cases

All eight supplied remote prompts are retained exactly. The extra skill case has explicit local sample input and an independent expected status. Remote positive expected behavior is a declared contract; its record oracle remains missing.

| Case | Prompt | Expected observation | Execution |
| --- | --- | --- | --- |
{table}

## Listing and release copy

The wizard-generated portal-copy-fields.json preserves the observed interface and review definitions. The package's display name is Fixture Plugin, subtitle Synthetic audit fixture, developer name Synthetic Fixture and category Developer Tools. The existing long description is Deterministic synthetic fixture for preflight validation. The existing release note is Synthetic fixture, no review or publication. These are observed definitions, not claims of a verified service or confirmed publisher identity. No replacement URLs, commerce choices or country targeting are invented.

## Demo outline — not a recording

When a separately authorized, runnable test environment exists, first show the exact installed package name/version and bind the capture to this archive hash. Demonstrate each of the five read prompts against controlled sample data and compare the actual returned record and observed state before/after. Demonstrate each of the three delete prompts and capture the safe unsupported-workflow response and absence of destructive calls/effects. Show the supplied-record skill case and its actual status output. Record actual tool names and arguments, output, side effects, host/version, observer, time and case IDs. Keep unrelated data and credentials off screen. Play back the full recording and verify reviewer access only when the user can record and authorizes the required environment. The declared demo URL was not played; no video exists in this preparation work.

## Reviewer access — unverified

The configuration declares anonymous access. No login flow or runtime access behavior was tested. Confirm the actual service's auth mode and whether an isolated reviewer account is needed in a later authorized environment. Put any credentials only in secure review fields, never this checkpoint or package. No account readiness is claimed.

## Evidence layers and outcome

Static package validation is observed separately from deterministic server tests, independent MCP checks, agent behavior, ChatGPT host runs, recording playback, legal facts and portal state. The latter layers are Blocked or Not run. The synthetic session cannot establish actual readiness, submission, approval or publication. Nothing has been uploaded or published.

## Next human-owned facts

The creator must confirm the publisher identity, rights to the submitted materials, actual data practices and support responsibility with an observation reference. These declarations are not supplied by this preparation. Host tests, a real recording, endpoint/reviewer access and unresolved runtime evidence remain open after that answer.
"""
(ROOT / "prepared-materials.md").write_text(intro)
static_pass = {
    "SS-PLAN-01": "Recorded source-defined goals, example prompts, expected outcomes, context and boundaries in prepared-materials.md. This is observed preparation, not successful execution.",
    "SS-TEST-03": "Separated static package findings, server/MCP tests, host behavior, recording, creator facts and portal stages in prepared-materials.md and the synthetic session. No runtime layer is promoted from static checks.",
    "SS-EVAL-02": "The session explicitly has synthetic=true, has no host evidence rows, and reports no authenticated actual host execution or portal action. Prepared expectations are labeled Not run.",
}
detail = {
    "SS-ARCH-02": "No server implementation or live inventory is supplied; actual operations and authorization cannot be inspected.",
    "SS-PLAN-02": "lookup is named only by review metadata; schemas, permissions, effects and failures are unavailable.",
    "SS-START-01": "The user cannot perform host tests now and prohibits target contact or execution.",
    "SS-START-02": "No UI assets are packaged; remote resource inventory is unavailable, so remote UI applicability cannot be established.",
    "SS-SERVER-01": "No server source is supplied and target execution/contact is prohibited; build and invocation were not run.",
    "SS-SERVER-02": "No UI or server implementation is available to compare against official examples; no execution evidence is inferred.",
    "SS-SKILL-02": "The sample skill has one read-and-report instruction and no linked supporting resources; actual agent handling remains unrun.",
    "SS-SKILL-03": "Source inspection found only a supplied-record instruction. The user's offline constraints were honored during preparation; installed instruction-conflict behavior is unrun.",
    "SS-UI-01": "No bundled UI implementation or resource inventory is supplied; remote UI support is unknown.",
    "SS-UI-02": "No UI is accessible in the authorized offline scope; display modes, accessibility and errors were not tested.",
    "SS-UI-03": "No live tool schemas or resource metadata were observed; applicability and structured output/UI metadata remain unknown.",
    "SS-EVENT-01": "No server implementation, protocol negotiation or capability inventory exists in the archive; event support is unknown.",
    "SS-EVENT-02": "No callback, signing, subscription implementation or runtime evidence is supplied; event applicability remains unknown.",
    "SS-EXT-01": "OpenAI package metadata is present, but relevant extension behavior in ChatGPT was not run.",
    "SS-COMMERCE-01": "No commerce declaration or implementation is supplied; actual commerce intent and eligibility are unconfirmed.",
    "SS-META-01": "The positive/negative prompts are prepared only; actual invocation and metadata behavior were not tested.",
    "SS-TEST-01": "No installation or product-host run was performed; the user deferred host testing.",
    "SS-TEST-02": "No observed tool inventory or schemas, controlled remote dataset, or calls are available; tool input coverage remains unrun.",
    "SS-POLICY-01": "The manifest explicitly describes a synthetic fixture, but utility and runtime capability claims have not been verified against a service.",
    "SS-POLICY-02": "No observed tools/list response or tool implementation is supplied; truthfulness and explicit booleans cannot be verified.",
    "SS-SEC-01": "Preparation treated the archive as data without execution; service permissions and trust boundaries remain unknown without implementation or tests.",
    "SS-SEC-02": "No retention, logging, deletion or data-minimization implementation/evidence or creator confirmation is supplied.",
    "SS-REVIEW-01": "The only endpoint is a controlled fixture.invalid address and was not contacted; production availability and isolated reviewer access are unverified.",
    "SS-REVIEW-03": "Five positive and three negative definitions exist and were retained in the plan. The user cannot record now; no accessible recording or playback was observed.",
    "SS-EVAL-01": "Source-derived cases and a sample-skill oracle are prepared, but independent record data and actual adversarial grading remain unavailable.",
}
decisions = []
for req in facts["requirement_catalog"]:
    key = req["id"]
    if facts["requirement_results"][key]["status"] in ("Passed", "Not applicable"):
        continue
    decisions.append({"id": key, "status": "Passed" if key in static_pass else "Blocked",
                      "observed_result": static_pass.get(key, detail.get(key, "Target-specific behavior remains unobserved within the authorized offline scope.")),
                      "evidence_reference": str(ROOT / "prepared-materials.md") + "; " + str(ROOT / "logs/01-inspect-target.stdout")})
(responses / "requirement-review.json").write_text(json.dumps({"decisions": decisions}, indent=2) + "\n")
print(json.dumps({"cases_prepared": len(cases), "remote_prompts_retained": 8, "requirement_dispositions": len(decisions), "behavioral_results_created": 0,
                  "materials": str(ROOT / "prepared-materials.md"), "plan_input": str(responses / "test-plan.json"), "review_input": str(responses / "requirement-review.json"),
                  "materials_sha256": hashlib.sha256((ROOT / "prepared-materials.md").read_bytes()).hexdigest()}, indent=2))
