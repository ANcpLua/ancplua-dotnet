#!/usr/bin/env python3
"""Record exact authorized preparation commands and their results."""
import datetime
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
LOGS = ROOT / "logs"
LOGS.mkdir(parents=True, exist_ok=True)
args = sys.argv[1:]
if len(args) < 2:
    raise SystemExit("usage: run_logged.py LABEL COMMAND [ARG ...]")
label, argv = args[0], args[1:]
if any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in label):
    raise SystemExit("label must use lowercase letters, digits, - or _")
out = LOGS / (label + ".stdout")
err = LOGS / (label + ".stderr")
if out.exists() or err.exists():
    raise SystemExit("choose a new log label")
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
out.write_bytes(result.stdout)
err.write_bytes(result.stderr)
record = dict(label=label, command=shlex.join(argv), argv=argv,
              cwd=str(ROOT), environment={"PYTHONDONTWRITEBYTECODE":"1"},
              started_at=started, ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              exit_code=result.returncode, stdout=str(out), stderr=str(err))
with (ROOT / "commands.jsonl").open("a") as stream:
    stream.write(json.dumps(record) + "\n")
print(json.dumps(record, indent=2))
sys.stdout.flush()
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)
