import collections
import hashlib
import io
import json
import pathlib
import re
import stat
import unicodedata
import urllib.parse
import zipfile

root = pathlib.Path(__file__).resolve().parent
request_path = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/submission.files/jobs/independent-review-request.json')
request_raw = request_path.read_bytes()
request = json.loads(request_raw)
sha = lambda raw: hashlib.sha256(raw).hexdigest()
output = {
    'inspection_type': 'Static parsing of exact archive bytes; no target code or endpoint executed',
    'request_sha256': sha(request_raw),
    'binding_from_request': request['binding'],
    'docs_sha256_from_request': request['docs_sha256'],
    'checks': {},
}
with zipfile.ZipFile(request['target_archive']) as z:
    entries = z.infolist()
    names = [item.filename for item in entries]
    normalized = [unicodedata.normalize('NFC', name).casefold() for name in names]
    bad_paths = [name for name in names if name != name.strip() or name.startswith('/') or '\\' in name or '..' in name.split('/') or '' in name.split('/')]
    unsupported = [entry.filename for entry in entries if not stat.S_ISREG(entry.external_attr >> 16) and not entry.is_dir()]
    output['checks']['archive'] = {
        'package_sha256_matches': sha(pathlib.Path(request['target_archive']).read_bytes()) == request['binding']['package_sha256'],
        'file_count': len(entries),
        'uncompressed_bytes': sum(entry.file_size for entry in entries),
        'duplicate_paths': [name for name, count in collections.Counter(names).items() if count > 1],
        'normalization_collisions': [name for name, count in collections.Counter(normalized).items() if count > 1],
        'unsafe_paths': bad_paths,
        'unsupported_entry_types': unsupported,
        'encrypted_entries': [entry.filename for entry in entries if entry.flag_bits & 1],
        'crc_bad_member': z.testzip(),
    }
    plugin = json.loads(z.read('plugin.json').decode('utf-8'))
    mcp = json.loads(z.read('mcp.json').decode('utf-8'))
    interface = plugin['extensions']['com.openai']['interface']
    review = plugin['extensions']['com.openai']['review']
    output['checks']['manifest'] = {
        'plugin_json_decodes': True,
        'mcp_json_decodes': True,
        'schema': plugin.get('$schema'),
        'name': plugin['name'],
        'version': plugin['version'],
        'name_format_basic_match': bool(re.fullmatch('[A-Za-z0-9][A-Za-z0-9_-]{0,63}', plugin['name'])),
        'version_basic_semver_match': bool(re.fullmatch(r'\d+\.\d+\.\d+', plugin['version'])),
        'listing_lengths': {field: len(interface[field]) for field in ('displayName', 'shortDescription', 'longDescription', 'developerName')},
        'category': interface['category'],
        'capability_count': len(interface['capabilities']),
        'logo_file_exists': interface['logo'].removeprefix('./') in names,
        'composer_icon_file_exists': interface['composerIcon'].removeprefix('./') in names,
        'positive_case_count': len(review['test_cases']['positive']),
        'negative_case_count': len(review['test_cases']['negative']),
        'positive_tool_names': sorted(set(case['tools_triggered'] for case in review['test_cases']['positive'])),
        'negative_case_fields': [sorted(case.keys()) for case in review['test_cases']['negative']],
        'review_fields_are_declarations_not_results': True,
    }
    urls = {field: interface[field] for field in ('websiteURL', 'supportURL', 'privacyPolicyURL', 'termsOfServiceURL')}
    urls['demo_recording_url'] = review['demo_recording_url']
    urls['mcp.fixture.url'] = mcp['mcpServers']['fixture']['url']
    output['checks']['urls'] = {field: {'value': url, 'scheme': urllib.parse.urlparse(url).scheme, 'hostname': urllib.parse.urlparse(url).hostname, 'live_check_performed': False} for field, url in urls.items()}
    skill = z.read('skills/review-fixture/SKILL.md').decode('utf-8')
    output['checks']['skill'] = {
        'text': skill,
        'name_matches_directory': 'name: review-fixture' in skill,
        'yaml_frontmatter_delimiters_present': skill.startswith('---\n') and '\n---\n' in skill[4:],
        'skill_plus_plugin_name_chars': len(plugin['name'] + ':review-fixture'),
        'body_line_count': len(skill.split('---\n', 2)[2].strip().splitlines()),
        'supporting_files_in_archive': [name for name in names if name.startswith('skills/review-fixture/') and name != 'skills/review-fixture/SKILL.md'],
        'runtime_observed': False,
    }
    png = z.read('assets/icon.png')
    (root / 'inspected-icon.png').write_bytes(png)
    try:
        from PIL import Image
        with Image.open(io.BytesIO(png)) as picture:
            picture.verify()
        with Image.open(io.BytesIO(png)) as picture:
            picture.load()
            output['checks']['icon'] = {'decoded': True, 'format': picture.format, 'width': picture.width, 'height': picture.height, 'mode': picture.mode, 'bytes': len(png), 'sha256': sha(png)}
    except Exception as error:
        output['checks']['icon'] = {'decoded': False, 'error': type(error).__name__ + ': ' + str(error)}
output['checks']['documentation_integrity'] = {
    'selected_count': len(request['documentation']['selected_ids']),
    'hash_mismatches': [doc['id'] for doc in request['documentation']['documents'] if sha(pathlib.Path(doc['file']).read_bytes()) != doc['sha256']],
    'current_status_per_request': all(doc['status'] == 'current' for doc in request['documentation']['documents'] if doc['id'] in request['documentation']['selected_ids']),
    'live_retrieval_by_reviewer': False,
}
print(json.dumps(output, indent=2, sort_keys=True))
