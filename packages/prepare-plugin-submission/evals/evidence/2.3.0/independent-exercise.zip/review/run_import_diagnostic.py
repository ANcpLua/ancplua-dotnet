import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys

sys.dont_write_bytecode = True
root = pathlib.Path(__file__).resolve().parent
source_root = pathlib.Path('/workspace/scratch/401e3bbb802b/submission-studio-2.3.0/skills/prepare-plugin-submission/scripts')
module_path = source_root / 'openai_core.py'
wizard_path = source_root / 'wizard.py'
state_path = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/restored/submission.json')
request_path = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/submission.files/jobs/independent-review-request.json')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
report_bytes = (root / 'report.json').read_bytes()
raw_bytes = (root / 'agent-output.txt').read_bytes()
assert sha(report_bytes) == '882d6a8e5b6f2d696b1cf7315c3d4049330848ed2db6e0adb15d3260ddad24f2'
assert sha(raw_bytes) == '45f4bb09f2c9a5514d9c15436c8f66f1652dd6e4dde84352b574745a9b08f0de'
report = json.loads(report_bytes)
request = json.loads(request_path.read_bytes())
module_bytes = module_path.read_bytes()
module_text = module_bytes.decode('utf-8')
module_sha = sha(module_bytes)
wizard_bytes = wizard_path.read_bytes()
wizard_text = wizard_bytes.decode('utf-8')
state_bytes = state_path.read_bytes()
state = json.loads(state_bytes)

def function_source(text, name):
    tree = ast.parse(text)
    node = next(item for item in tree.body if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == name)
    return '\n'.join(text.splitlines()[node.lineno - 1:node.end_lineno]) + '\n'

validator_source = function_source(module_text, 'validate_rule')
document_records_source = function_source(wizard_text, 'document_records')
snapshot = root / ('diagnostic-openai_core-' + module_sha + '.py')
snapshot.write_bytes(module_bytes)
(root / 'diagnostic-validate_rule-source.txt').write_text(validator_source, encoding='utf-8')
(root / 'diagnostic-document_records-source.txt').write_text(document_records_source, encoding='utf-8')
spec = importlib.util.spec_from_file_location('independent_diagnostic_openai_core', snapshot)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
function_globals = {
    'copy': copy,
    'Path': pathlib.Path,
    'file_sha': lambda path: sha(pathlib.Path(path).read_bytes()),
    'policy': policy,
}
exec(compile(document_records_source, str(wizard_path) + ':document_records-snapshot', 'exec'), function_globals)
work = pathlib.Path(state['artifacts']['session_workspace'])
documents = function_globals['document_records'](copy.deepcopy(state), work)
rules = [row for row in report['findings'] if row['classification'] == 'official_requirement']
request_docs = {doc['id']: doc for doc in request['documentation']['documents']}
for row in rules:
    doc = next(doc for doc in documents if doc['id'] == row['source_id'])
    assert doc['sha256'] == row['source_sha256'] == request_docs[doc['id']]['sha256']
    assert sha(pathlib.Path(doc['file']).read_bytes()) == doc['sha256']
    assert row['quote'] in doc['text']

context_path = root / 'diagnostic-context.json'
context = {'validator_snapshot': str(snapshot), 'rules': rules, 'documents': documents}
context_path.write_text(json.dumps(context, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assessments = {
    'IR-001': {
        'assessment': 'mandatory_imperative',
        'classification_retained': 'official_requirement',
        'basis': 'The Deploy the endpoint section directs public submitters to deploy a stable publicly reachable HTTPS endpoint. Its surrounding paragraphs explicitly call this a public submission requirement, introduce what the production endpoint must do, and require continued public reachability. The deploy imperative is not softened by should, may, recommend, or suggest.',
        'context_lines': [265, 288],
    },
    'IR-002': {
        'assessment': 'explicit_must_requirement',
        'classification_retained': 'official_requirement',
        'basis': 'The quoted sentence explicitly says public URLs must be accessible and identify the same publisher. It is within Check metadata in the submission procedure. The recording field is separately identified as a reviewer-accessible walkthrough; the diagnostic does not establish actual accessibility or content.',
        'context_lines': [23, 35],
    },
    'IR-003': {
        'assessment': 'mandatory_acceptance_exclusion',
        'classification_retained': 'official_requirement',
        'basis': 'Trial or demo plugins will not be accepted is an unqualified acceptance exclusion in Quality and reliability under Plugin fundamentals. The preceding sentence uses should for stability/completeness; that separate advisory sentence does not soften the following explicit will-not-be-accepted exclusion.',
        'context_lines': [14, 25],
    },
    'IR-004': {
        'assessment': 'explicit_prohibition',
        'classification_retained': 'official_requirement',
        'basis': 'Do not append is an explicit prohibition in the Names bullet of public plugin naming rules. The same section requires clear and accurate plugin names. The earlier Avoid overly generic names clause is separate; it does not turn the Do not append prohibition into optional guidance.',
        'context_lines': [14, 25],
    },
}

results = []
for rule in rules:
    row_id = rule['id']
    argv = [sys.executable, '-B', str(root / 'diagnostic_validate_row.py'), str(context_path), row_id]
    completed = subprocess.run(argv, cwd=root, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}, capture_output=True)
    stdout_path = root / ('diagnostic-' + row_id + '.stdout.txt')
    stderr_path = root / ('diagnostic-' + row_id + '.stderr.txt')
    stdout_path.write_bytes(completed.stdout)
    stderr_path.write_bytes(completed.stderr)
    doc = next(doc for doc in documents if doc['id'] == rule['source_id'])
    start, end = assessments[row_id]['context_lines']
    lines = doc['text'].splitlines()
    results.append({
        'id': row_id,
        'input_classification': rule['classification'],
        'source_id': rule['source_id'],
        'source_sha256': rule['source_sha256'],
        'source_file': doc['file'],
        'source_role': doc['role'],
        'source_status': doc['status'],
        'quote': rule['quote'],
        'exact_quote_present_in_saved_primary': rule['quote'] in doc['text'],
        'exact_quote_present_in_indexed_sections': rule['quote'] in '\n'.join(section['text'] for section in doc['sections']),
        'validator_result': 'pass' if completed.returncode == 0 else 'error',
        'command': {'argv': argv, 'cwd': str(root), 'environment_overrides': {'PYTHONDONTWRITEBYTECODE': '1'}},
        'exit_code': completed.returncode,
        'stdout': completed.stdout.decode('utf-8'),
        'stderr': completed.stderr.decode('utf-8'),
        'stdout_file': stdout_path.name,
        'stdout_sha256': sha(completed.stdout),
        'stderr_file': stderr_path.name,
        'stderr_sha256': sha(completed.stderr),
        'independent_assessment': assessments[row_id],
        'surrounding_primary_context': {'line_start': start, 'line_end': end, 'text': '\n'.join(lines[start - 1:end])},
    })

assert (root / 'report.json').read_bytes() == report_bytes
assert (root / 'agent-output.txt').read_bytes() == raw_bytes
module_sha_after = sha(module_path.read_bytes())
diagnostic = {
    'schema_version': 1,
    'kind': 'reviewer-owned-isolated-import-diagnostic',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer_id': report['reviewer_id'],
    'provider': report['provider'],
    'origin': 'observed',
    'request_sha256': sha(request_path.read_bytes()),
    'docs_sha256': report['docs_sha256'],
    'binding': report['binding'],
    'preserved_report': {'file': 'report.json', 'sha256': sha(report_bytes), 'unchanged': True},
    'preserved_raw_report': {'file': 'agent-output.txt', 'sha256': sha(raw_bytes), 'unchanged': True},
    'validator': {
        'installed_module_path': str(module_path),
        'module_sha256_before': module_sha,
        'module_sha256_after': module_sha_after,
        'installed_file_changed_during_diagnostic': module_sha != module_sha_after,
        'snapshot_file': snapshot.name,
        'snapshot_sha256': sha(snapshot.read_bytes()),
        'function_source_file': 'diagnostic-validate_rule-source.txt',
        'function_source_sha256': sha(validator_source.encode('utf-8')),
        'function_source': validator_source,
        'execution_method': 'Imported the exact captured full openai_core source from a reviewer-owned immutable-byte snapshot; called its unchanged validate_rule once per official_requirement in separate child processes. Bytecode writes were disabled.',
    },
    'document_records': {
        'state_file': str(state_path),
        'state_sha256_at_read': sha(state_bytes),
        'session_workspace': str(work),
        'wizard_source_path': str(wizard_path),
        'wizard_source_sha256_at_read': sha(wizard_bytes),
        'function_source_file': 'diagnostic-document_records-source.txt',
        'function_source_sha256': sha(document_records_source.encode('utf-8')),
        'method': 'Compiled unchanged wizard.document_records function source with copy, Path, the same SHA-256 file reader, and the captured policy module; called it on a deep copy of restored state. Its path, symlink, and hash guards ran. No other wizard workflow function ran.',
        'record_count': len(documents),
        'used_primary_hashes_match_original_request': True,
        'context_file': context_path.name,
        'context_sha256': sha(context_path.read_bytes()),
    },
    'rows': results,
    'conclusion': 'The source classifications remain unchanged. In the captured implementation, a narrow mandatory-keyword allowlist rejects a public-submission deploy imperative, an explicit will-not-be-accepted exclusion, and an explicit Do-not prohibition. Their surrounding current-primary sections support treating them as mandatory; the rejection does not establish that they are mere guidance. The row using must passes. This diagnostic does not change or strengthen any target-runtime claim.',
    'limits': 'No target plugin code, endpoint, host test, scan, portal, upload, or creator declaration was executed. No installed implementation or main wizard state was edited. Runtime/accessibility and actual submission outcomes remain unverified.',
}
output_path = root / 'import-diagnostic.json'
with output_path.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(diagnostic, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({
    'diagnostic_file': str(output_path),
    'diagnostic_sha256': sha(output_path.read_bytes()),
    'validator_module_sha256': module_sha,
    'validator_function_sha256': diagnostic['validator']['function_source_sha256'],
    'installed_file_changed_during_diagnostic': module_sha != module_sha_after,
    'rows': [{'id': row['id'], 'result': row['validator_result'], 'exit_code': row['exit_code']} for row in results],
    'report_unchanged': True,
    'raw_report_unchanged': True,
    'classification_changes': 0,
}, indent=2))
