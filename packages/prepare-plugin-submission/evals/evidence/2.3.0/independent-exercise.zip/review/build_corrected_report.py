import copy
import datetime
import hashlib
import importlib.util
import json
import pathlib
import sys

sys.dont_write_bytecode = True
root = pathlib.Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
request_path = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/submission.files/jobs/independent-review-request.json')
request_bytes = request_path.read_bytes()
request = json.loads(request_bytes)
original_report_bytes = (root / 'report.json').read_bytes()
original_raw_bytes = (root / 'agent-output.txt').read_bytes()
assert sha(original_report_bytes) == '882d6a8e5b6f2d696b1cf7315c3d4049330848ed2db6e0adb15d3260ddad24f2'
assert sha(original_raw_bytes) == '45f4bb09f2c9a5514d9c15436c8f66f1652dd6e4dde84352b574745a9b08f0de'
report = copy.deepcopy(json.loads(original_report_bytes))
doc = next(doc for doc in request['documentation']['documents'] if doc['id'] == 'build.skills')
doc_bytes = pathlib.Path(doc['file']).read_bytes()
assert sha(doc_bytes) == doc['sha256'] == '1e5b98c53c48c3322efed9fa1b43e12ac4db2e4b89d567aba167a60684bab86e'
assert doc['role'] == 'primary' and doc['status'] == 'current'
quote = '- When the workflow should ask a question, stop, or decline.'
assert quote in doc_bytes.decode('utf-8')
applicability = 'The package contains skills/review-fixture/SKILL.md. Its confirmed boundary cases expect missing-record clarification and explanation of unsupported remote changes. The current primary skills guide advises stating when skill workflows should ask a question, stop, or decline.'
observed = 'The packaged skill body consists only of Read the supplied sample record and report its status. It contains no explicit missing-record, missing/ambiguous-status, or unsupported-remote-change instruction. This is a static instruction observation; no installed-host boundary behavior was executed or inferred.'
row = next(row for row in report['findings'] if row['id'] == 'IR-006')
assert row['classification'] == 'official_guidance'
row.update({'source_id': doc['id'], 'source_sha256': doc['sha256'], 'quote': quote, 'applicability': applicability, 'observed_result': observed})

amendment = '''

ACTUAL REVIEWER AMENDMENT — 2026-10-16 UTC

Reviewer: runtime-forward-independent-static-agent-20261016
Provider: OpenAI Codex collaboration agent /root/runtime_forward/independent_review, the same independent reviewer that produced the original report.
Origin: observed

The preceding raw report is reproduced byte for byte. This amendment adds current primary-source fields for IR-006, retaining official_guidance. The original semantic conclusions and all six findings remain unchanged. The word should in the cited boundary guidance is why this remains guidance rather than a mandatory requirement. The amended import adapter is report-corrected.json; its evidence points to this separate actual amended raw output.

Original report.json SHA-256: 882d6a8e5b6f2d696b1cf7315c3d4049330848ed2db6e0adb15d3260ddad24f2
Original agent-output.txt SHA-256: 45f4bb09f2c9a5514d9c15436c8f66f1652dd6e4dde84352b574745a9b08f0de
Both originals remain unchanged.

IR-006 source evidence
Classification retained: official_guidance
Source path: skills/review-fixture/SKILL.md
Source ID: build.skills
Source SHA-256: 1e5b98c53c48c3322efed9fa1b43e12ac4db2e4b89d567aba167a60684bab86e
Source role/status: primary/current, as recorded in the exact saved request and verified against its retained bytes.
Exact quote: - When the workflow should ask a question, stop, or decline.
Applicability: ''' + applicability + '''
Observed result: ''' + observed + '''

The supporting sentence appears under Define the workflow boundary in the retained Build skills snapshot. I read the surrounding section independently during the original inspection and retained the exact output. It lists expected input, steps, output, facts not to infer, and question/stop/decline points. This amendment supplies its provenance and the actual static observation; it does not turn a recommendation into a mandatory rule or claim a host test result.

The reviewer-owned validator diagnostic is separate. Its exact captured current implementation accepts all four original official_requirement rows, with exit 0 per row. That implementation differs from the earlier directly inspected lexical gate. Those classifications remain independently supported by their surrounding primary text; no classification was changed to advance import. The finalized import-diagnostic.json records exact commands, exits, outputs, captured validator source/hash, and the source-context assessments. No target plugin execution, endpoint request, upload, portal action, or creator-owned declaration was made.

The current request binding, documentation-set binding, request hash, reviewer identity, summary, and substantive findings are retained from the original. This new amended raw output is to remain unedited.
'''
corrected_raw_path = root / 'agent-output-corrected.txt'
with corrected_raw_path.open('xb') as stream:
    stream.write(original_raw_bytes + amendment.encode('utf-8'))
corrected_raw_bytes = corrected_raw_path.read_bytes()
report['evidence'] = {'file': corrected_raw_path.name, 'sha256': sha(corrected_raw_bytes)}
report['correction_provenance'] = {
    'kind': 'actual-independent-reviewer-amendment',
    'reviewer_id': report['reviewer_id'],
    'provider': report['provider'],
    'origin': 'observed',
    'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'original_report': {'file': 'report.json', 'sha256': sha(original_report_bytes), 'unchanged': True},
    'original_evidence': {'file': 'agent-output.txt', 'sha256': sha(original_raw_bytes), 'unchanged': True},
    'amended_finding_ids': ['IR-006'],
    'classification_changes': [],
    'semantic_changes': [],
    'reason': 'Supply the actual exact current-primary supporting span, source hash, applicability, and observed static result for the retained official_guidance finding.',
}
assert report['binding'] == request['binding']
assert report['docs_sha256'] == request['docs_sha256']
assert report['request_sha256'] == sha(request_bytes)
assert report['reviewer_id'] != request['drafter_id']
for finding in report['findings']:
    if finding['classification'] not in ('official_requirement', 'official_guidance'):
        continue
    source = next(source for source in request['documentation']['documents'] if source['id'] == finding['source_id'])
    content = pathlib.Path(source['file']).read_bytes()
    assert source['role'] == 'primary' and source['status'] == 'current'
    assert sha(content) == source['sha256'] == finding['source_sha256']
    assert finding['quote'] in content.decode('utf-8')
    assert finding['applicability'] and finding['observed_result']

module_path = pathlib.Path('/workspace/scratch/401e3bbb802b/submission-studio-2.3.0/skills/prepare-plugin-submission/scripts/openai_core.py')
module_bytes = module_path.read_bytes()
snapshot = root / ('correction-openai_core-' + sha(module_bytes) + '.py')
snapshot.write_bytes(module_bytes)
spec = importlib.util.spec_from_file_location('independent_correction_openai_core', snapshot)
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
context = json.loads((root / 'diagnostic-context.json').read_text(encoding='utf-8'))
result = policy.validate_rule(row, context['documents'])
assert result['id'] == 'build.skills'
report_path = root / 'report-corrected.json'
with report_path.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
assert (root / 'report.json').read_bytes() == original_report_bytes
assert (root / 'agent-output.txt').read_bytes() == original_raw_bytes
assert corrected_raw_path.read_bytes() == corrected_raw_bytes
validation = {
    'report_file': str(report_path),
    'report_sha256': sha(report_path.read_bytes()),
    'raw_report_file': str(corrected_raw_path),
    'raw_report_sha256': sha(corrected_raw_bytes),
    'original_report_unchanged': True,
    'original_report_sha256': sha(original_report_bytes),
    'original_raw_report_unchanged': True,
    'original_raw_report_sha256': sha(original_raw_bytes),
    'binding_unchanged': True,
    'request_sha256': sha(request_bytes),
    'docs_sha256': request['docs_sha256'],
    'amended_finding': 'IR-006',
    'classification': 'official_guidance',
    'semantic_changes': 0,
    'exact_current_primary_source_checks': 'passed for all five official findings',
    'IR_006_isolated_validate_rule_result': 'pass',
    'validator_source_path': str(module_path),
    'validator_module_sha256': sha(module_bytes),
    'validator_snapshot_file': snapshot.name,
    'validator_file_unchanged_during_check': module_path.read_bytes() == module_bytes,
}
(root / 'correction-validation.json').write_text(json.dumps(validation, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print(json.dumps(validation, indent=2, ensure_ascii=False))
