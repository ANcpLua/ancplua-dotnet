import hashlib
import json
import pathlib
import struct
import sys
import zipfile

request_file = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/submission.files/jobs/independent-review-request.json')
request_bytes = request_file.read_bytes()
request = json.loads(request_bytes)
mode = sys.argv[1]
sha = lambda raw: hashlib.sha256(raw).hexdigest()

if mode == 'inventory':
    print('REQUEST_PATH:', request_file)
    print('REQUEST_SHA256:', sha(request_bytes))
    print('REQUEST_CONTENT:')
    print(request_bytes.decode('utf-8'), end='')
    archive = pathlib.Path(request['target_archive'])
    print('\nARCHIVE_PATH:', archive)
    print('ARCHIVE_SHA256:', sha(archive.read_bytes()))
    print('ARCHIVE_EXPECTED_SHA256:', request['binding']['package_sha256'])
    with zipfile.ZipFile(archive) as z:
        print('ZIP_INTEGRITY_BAD_MEMBER:', z.testzip())
        print('ZIP_MEMBERS:')
        for entry in z.infolist():
            raw = z.read(entry) if not entry.is_dir() else b''
            print(json.dumps({'path': entry.filename, 'bytes': entry.file_size, 'compressed_bytes': entry.compress_size, 'mode': oct(entry.external_attr >> 16), 'sha256': sha(raw) if not entry.is_dir() else None}, sort_keys=True))
            if entry.filename.endswith('.png'):
                print('PNG_HEADER:', raw[:33].hex())
                if raw.startswith(b'\x89PNG\r\n\x1a\n'):
                    print('PNG_IHDR:', struct.unpack('>IIBBBBB', raw[16:29]))
    print('DOCUMENT_HASHES:')
    for doc in request['documentation']['documents']:
        data = pathlib.Path(doc['file']).read_bytes()
        print(json.dumps({'id': doc['id'], 'path': doc['file'], 'bytes': len(data), 'expected_sha256': doc['sha256'], 'actual_sha256': sha(data), 'matches': sha(data) == doc['sha256'], 'selected': doc['id'] in request['documentation']['selected_ids'], 'status': doc['status'], 'role': doc['role']}, sort_keys=True))
elif mode == 'source':
    with zipfile.ZipFile(request['target_archive']) as z:
        for entry in z.infolist():
            if entry.is_dir():
                continue
            print('\n===== SOURCE FILE:', entry.filename, '=====')
            try:
                content = z.read(entry).decode('utf-8')
            except UnicodeDecodeError:
                print('[binary file; inspected by metadata/hash only]')
                continue
            for number, line in enumerate(content.splitlines(), 1):
                print(f'{number:04d}: {line}')
elif mode == 'docs':
    selected = sys.argv[2:] or request['documentation']['selected_ids']
    for doc in request['documentation']['documents']:
        if doc['id'] not in selected:
            continue
        print('\n===== SELECTED DOCUMENT:', doc['id'], '=====')
        print('URL:', doc['url'])
        print('SHA256:', sha(pathlib.Path(doc['file']).read_bytes()))
        content = pathlib.Path(doc['file']).read_text(encoding='utf-8')
        for number, line in enumerate(content.splitlines(), 1):
            print(f'{number:04d}: {line}')
elif mode == 'doc-lines':
    doc = next(item for item in request['documentation']['documents'] if item['id'] == sys.argv[2])
    start, end = int(sys.argv[3]), int(sys.argv[4])
    print('DOC:', doc['id'], 'URL:', doc['url'], 'SHA256:', doc['sha256'])
    for number, line in enumerate(pathlib.Path(doc['file']).read_text(encoding='utf-8').splitlines(), 1):
        if start <= number <= end:
            print(f'{number:04d}: {line}')
elif mode == 'doc-prose':
    selected = sys.argv[2:] or request['documentation']['selected_ids']
    for doc in request['documentation']['documents']:
        if doc['id'] not in selected:
            continue
        print('\n===== SELECTED DOCUMENT:', doc['id'], '=====')
        print('URL:', doc['url'])
        print('SHA256:', sha(pathlib.Path(doc['file']).read_bytes()))
        inside_code = False
        for number, line in enumerate(pathlib.Path(doc['file']).read_text(encoding='utf-8').splitlines(), 1):
            if line.lstrip().startswith('```'):
                inside_code = not inside_code
                if inside_code:
                    print(f'{number:04d}: [code example omitted in this prose view]')
                continue
            if not inside_code and line.strip():
                print(f'{number:04d}: {line}')
else:
    raise SystemExit('Unknown inspection mode: ' + mode)
