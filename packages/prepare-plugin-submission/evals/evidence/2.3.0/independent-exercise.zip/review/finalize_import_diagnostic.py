import datetime
import hashlib
import json
import pathlib

root = pathlib.Path(__file__).resolve().parent
sha = lambda raw: hashlib.sha256(raw).hexdigest()
path = root / 'import-diagnostic.json'
initial_bytes = path.read_bytes()
initial = json.loads(initial_bytes)
assert all(row['validator_result'] == 'pass' and row['exit_code'] == 0 for row in initial['rows'])
preserved_path = root / 'import-diagnostic-initial-generated.json'
with preserved_path.open('xb') as stream:
    stream.write(initial_bytes)
initial['initial_generated_diagnostic'] = {
    'file': preserved_path.name,
    'sha256': sha(initial_bytes),
    'correction_reason': 'The initial generated conclusion assumed the earlier inspected lexical gate. The actual captured current-module subprocess outputs all passed. This finalization corrects that prose; commands, exits, outputs, source snapshot, and per-row assessments remain unchanged.',
}
initial['earlier_validator_source_observation'] = {
    'file': 'diagnostic-source-locations.stdout.txt',
    'sha256': sha((root / 'diagnostic-source-locations.stdout.txt').read_bytes()),
    'observation': 'Before the immutable snapshot was captured, the directly inspected source had a mandatory-keyword allowlist lacking deploy, do not, and will not be accepted. The later captured current module differs. The earlier source body is preserved in this exact inspection output; no complete-module hash was taken at that earlier observation.',
}
initial['conclusion'] = 'All four official_requirement rows pass against the exact captured current module, with exit code 0 for each. The current module differs from the earlier directly inspected keyword gate. Independent assessment retains all four classifications: the deploy directive is a public-submission imperative, public-URL accessibility uses must, trial/demo nonacceptance is an explicit exclusion, and Do not append is an explicit prohibition. No finding was reclassified to obtain acceptance. This source-validity diagnostic does not establish target runtime behavior or an actual portal outcome.'
initial['finalized_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
path.write_text(json.dumps(initial, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
assert sha((root / 'report.json').read_bytes()) == '882d6a8e5b6f2d696b1cf7315c3d4049330848ed2db6e0adb15d3260ddad24f2'
assert sha((root / 'agent-output.txt').read_bytes()) == '45f4bb09f2c9a5514d9c15436c8f66f1652dd6e4dde84352b574745a9b08f0de'
print(json.dumps({
    'diagnostic_file': str(path),
    'diagnostic_sha256': sha(path.read_bytes()),
    'preserved_first_generated_file': str(preserved_path),
    'preserved_first_generated_sha256': sha(initial_bytes),
    'rows': [{'id': row['id'], 'result': row['validator_result'], 'exit_code': row['exit_code']} for row in initial['rows']],
    'original_report_unchanged': True,
    'original_raw_report_unchanged': True,
    'classification_changes': 0,
}, indent=2))
