import importlib.util
import json
import pathlib
import sys
import traceback

sys.dont_write_bytecode = True
context_path = pathlib.Path(sys.argv[1])
row_id = sys.argv[2]
context = json.loads(context_path.read_text(encoding='utf-8'))
spec = importlib.util.spec_from_file_location('independent_frozen_openai_core', context['validator_snapshot'])
policy = importlib.util.module_from_spec(spec)
spec.loader.exec_module(policy)
rule = next(row for row in context['rules'] if row['id'] == row_id)
documents = context['documents']
try:
    result = policy.validate_rule(rule, documents)
except Exception as exc:
    print(json.dumps({'id': row_id, 'result': 'error', 'exception': type(exc).__name__, 'message': str(exc)}, ensure_ascii=False, sort_keys=True))
    traceback.print_exc(file=sys.stderr)
    raise SystemExit(2)
else:
    print(json.dumps({'id': row_id, 'result': 'pass', 'returned_document_id': result['id']}, ensure_ascii=False, sort_keys=True))
