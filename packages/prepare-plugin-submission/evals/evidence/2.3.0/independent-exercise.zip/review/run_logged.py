import datetime
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
label = sys.argv[1]
argv = sys.argv[2:]
result = subprocess.run(argv, cwd=root, capture_output=True)
(root / (label + '.stdout.txt')).write_bytes(result.stdout)
(root / (label + '.stderr.txt')).write_bytes(result.stderr)
record = {
    'label': label,
    'timestamp_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'argv': argv,
    'cwd': str(root),
    'exit_code': result.returncode,
    'stdout_file': label + '.stdout.txt',
    'stderr_file': label + '.stderr.txt',
}
with (root / 'inspection-commands.jsonl').open('a', encoding='utf-8') as stream:
    stream.write(json.dumps(record, sort_keys=True) + '\n')
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)
