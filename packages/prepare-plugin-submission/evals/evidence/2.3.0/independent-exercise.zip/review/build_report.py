import hashlib
import json
import pathlib
import re
import zipfile

root = pathlib.Path(__file__).resolve().parent
request_path = pathlib.Path('/workspace/scratch/401e3bbb802b/ss230-forward/submission.files/jobs/independent-review-request.json')
request_raw = request_path.read_bytes()
request = json.loads(request_raw)
raw_path = root / 'agent-output.txt'
raw_bytes = raw_path.read_bytes()
raw = raw_bytes.decode('utf-8')
sha = lambda value: hashlib.sha256(value).hexdigest()
assert sha(request_raw) == '8f94b016ce8598b6551c11ff05deead6cf91d6ea7f9e654606f6f38307b72ec2'
assert request['docs_sha256'] == '06624aca94f5a95e5a1cb241d8bde17a80bb7efc7edea64fb6191e11269e0ade'
assert sha(pathlib.Path(request['target_archive']).read_bytes()) == request['binding']['package_sha256']

matches = list(re.finditer(r'^(IR-\d+) — ([a-z_]+) — (.+)$', raw, re.M))
findings = []
for index, match in enumerate(matches):
    end = matches[index + 1].start() if index + 1 < len(matches) else raw.index('\nUnverified and excluded conclusions\n')
    section = raw[match.end():end].strip()
    def field(label):
        found = re.search(r'^' + re.escape(label) + r': (.+)$', section, re.M)
        if not found:
            raise ValueError('Missing field ' + label + ' in ' + match.group(1))
        return found.group(1)
    finding = {
        'id': match.group(1),
        'classification': match.group(2),
        'source_path': match.group(3),
        'message': field('Message'),
        'fix': field('Fix'),
    }
    if finding['classification'] == 'official_requirement':
        quote = re.search(r'^Exact quote:\s?(.+?)\nApplicability:', section, re.M | re.S).group(1)
        finding.update({
            'source_id': field('Source ID'),
            'source_sha256': field('Source SHA-256'),
            'quote': quote,
            'applicability': field('Applicability'),
            'observed_result': field('Observed result'),
        })
    findings.append(finding)

report = {
    'schema_version': 1,
    'binding': request['binding'],
    'docs_sha256': request['docs_sha256'],
    'request_sha256': sha(request_raw),
    'reviewer_id': re.search(r'^Reviewer: (.+)$', raw, re.M).group(1),
    'provider': re.search(r'^Provider: (.+)$', raw, re.M).group(1),
    'origin': 'observed',
    'summary': raw.split('\nSummary\n', 1)[1].split('\n\nScope and method\n', 1)[0].strip(),
    'findings': findings,
    'evidence': {'file': 'agent-output.txt', 'sha256': sha(raw_bytes)},
}

assert report['reviewer_id'] != request['drafter_id']
assert report['summary']
assert len(findings) == 6
allowed = {'structural_check', 'engineering_advice', 'official_guidance', 'official_requirement'}
documents = {doc['id']: doc for doc in request['documentation']['documents']}
with zipfile.ZipFile(request['target_archive']) as archive:
    inventory = set(archive.namelist())
for finding in findings:
    assert finding['classification'] in allowed
    assert finding['source_path'] in inventory
    assert all(isinstance(finding[key], str) and finding[key].strip() for key in ('id', 'message', 'fix', 'source_path'))
    if finding['classification'] == 'official_requirement':
        doc = documents[finding['source_id']]
        doc_raw = pathlib.Path(doc['file']).read_bytes()
        assert doc['role'] == 'primary' and doc['status'] == 'current'
        assert doc['id'] in request['documentation']['selected_ids']
        assert sha(doc_raw) == finding['source_sha256'] == doc['sha256']
        assert finding['quote'] in doc_raw.decode('utf-8'), finding['id']
        assert finding['applicability'] and finding['observed_result']

report_path = root / 'report.json'
with report_path.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
assert raw_path.read_bytes() == raw_bytes
assert json.loads(report_path.read_text(encoding='utf-8')) == report
print(json.dumps({
    'report_file': str(report_path),
    'report_sha256': sha(report_path.read_bytes()),
    'raw_report_file': str(raw_path),
    'raw_report_sha256': sha(raw_bytes),
    'request_sha256': report['request_sha256'],
    'docs_sha256': report['docs_sha256'],
    'findings': len(findings),
    'official_requirements_with_exact_current_primary_quotes': sum(finding['classification'] == 'official_requirement' for finding in findings),
    'required_field_checks': 'passed',
    'archive_path_checks': 'passed',
    'quote_and_document_hash_checks': 'passed',
    'raw_report_unchanged': True,
    'host_case_passes_claimed': 0,
}, indent=2))
