"""OpenAI preparation rules. Pure transforms; empty evidence never proves readiness."""
import copy
import hashlib
import json

BASE = 'https://developers.openai.com/plugins/'
SOURCES = {
    'package': BASE + 'build/plugins', 'submission': BASE + 'deploy/submission',
    'policy': BASE + 'plugin-guidelines', 'auth': BASE + 'build/auth',
    'testing': BASE + 'deploy/connect-chatgpt', 'review': BASE + 'deploy/app-review',
    'security': BASE + 'guides/security-privacy',
    'protocol': 'https://modelcontextprotocol.io/specification/2026-07-28',
    'sdk': 'https://ts.sdk.modelcontextprotocol.io/v2/',
}
# Suggested engineering checks, not invented official clause identifiers.
CHECKS = [
    ('architecture', 'Inspect source, operations, components, data and intended hosts', 'package'),
    ('package', 'Inspect the finished archive and effective configuration', 'package'),
    ('protocol', 'Observe actual modern negotiation and requested capabilities', 'protocol'),
    ('tools', 'Execute each exposed tool and verify result, errors and effects', 'testing'),
    ('auth', 'Test discovery, permission boundaries, denial and credential lifecycle', 'auth'),
    ('security', 'Test data isolation, injection boundaries and secret handling', 'security'),
    ('skills', 'Load packaged skills and evaluate realistic tasks', 'testing'),
    ('ui', 'Exercise optional UI in each claimed host', 'testing'),
    ('review', 'Verify applicable review cases on intended product surfaces', 'review'),
    ('listing', 'Prepare accurate listing, publisher facts and real demo evidence', 'submission'),
    ('maintenance', 'Prepare rollout, rollback, observability and regression work', 'submission'),
]


def binding(facts):
    def digest(value):
        return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    return dict(integration_id=facts['id'], source_revision=facts['source_revision'],
                input_sha256=digest(facts), inventory_sha256=digest(facts.get('tools', [])))


def requirements(facts):
    return [dict(requirement_id='SS-OAI-' + name.upper(), platform='openai',
                 classification='recommended_engineering_practice', applicability='Determine from inspected source',
                 summary=summary, source_url=SOURCES[source], source_checked_at=None,
                 source_revision=None, implementation_revision=facts['source_revision'],
                 protocol_version='2026-07-28' if name == 'protocol' else None,
                 transport=facts.get('server', {}).get('connection', {}).get('transport'),
                 verification='Agent must inspect current primary page and execute applicable checks',
                 status='Not run', observed_result=None, evidence=[])
            for name, summary, source in CHECKS]


def readiness(facts, plan):
    findings = []
    server = facts.get('server', {})
    skills_only = facts.get('components', {}).get('mcp') is False and not server.get('connection')
    if facts['source_revision'] == 'UNRECORDED':
        findings.append(dict(code='source_revision_missing', status='Blocked', message='Record actual revision or source digest.'))
    if not facts.get('hosts'):
        findings.append(dict(code='hosts_missing', status='Blocked', message='Declare intended OpenAI product/API surfaces.'))
    if not skills_only and not server.get('connection'):
        findings.append(dict(code='connection_unknown', status='Blocked', message='Inspect MCP declarations or explicitly record components.mcp: false.'))
    if server.get('connection', {}).get('transport') == 'sse':
        findings.append(dict(code='legacy_transport', status='Blocked', message='Migrate legacy SSE to a modern supported transport and test negotiation.'))
    return dict(binding=binding(facts), platform='openai', sources=SOURCES,
                source_dates='Check each requirement individually; inventory URLs are not retrieval evidence.',
                findings=findings, requirements=requirements(facts), readiness='Not verified',
                live_verification_performed=False,
                auth_checks=[dict(check=k, status='Not applicable' if skills_only else 'Not run', evidence=[])
                             for k in ('discovery', 'registration', 'pkce', 'redirects', 'audience', 'scopes', 'expiry', 'refresh', 'denial', 'revocation', 'tenant_isolation')],
                host_checks=[dict(host=h, status='Not run', evidence=[]) for h in facts.get('hosts', [])],
                next_actions=[f['message'] for f in findings] + ['Implement and run applicable tests; keep product-host evidence separate.'])


def policy_matrix(facts):
    return dict(binding=binding(facts), platform='openai', source=SOURCES['policy'],
                source_checked_at=None, requirements=requirements(facts),
                preparation_complete=False, legal_compliance_certified=False,
                decisions=copy.deepcopy(facts.get('policy', {})))


def obligations(facts):
    return dict(binding=binding(facts), platform='openai', source=SOURCES['submission'],
                source_checked_at=None, publisher=copy.deepcopy(facts.get('publisher', {})),
                required_creator_facts=['legal identity', 'rights', 'actual data practices', 'support', 'reviewer access'],
                preparation_complete=False, terms_accepted_by_tool=False, submission_performed=False)


def release_plan(facts, plan):
    return dict(binding=binding(facts), platform='openai', source=SOURCES['submission'],
                source_checked_at=None, current_and_proposed=copy.deepcopy(facts.get('release', {})),
                actions=dict(server='Deploy and exercise actual endpoint using its owning deployment process.',
                             package='Build and validate changed skills/metadata in a new version; preserve existing identity.',
                             listing='Read current portal guidance; track draft, review, approval and publication separately.'),
                regression_case_ids=[c['id'] for c in plan['cases']],
                rollout='Supply actual deployment components and owner.', rollback='Supply a tested recovery procedure.',
                ready_for_owner_review=False, deployment_performed=False, continuous_monitoring_configured=False)


def handoff_records(facts, plan):
    """Output path -> JSON object, all facts labelled as supplied, all tests unrun."""
    base = dict(binding=binding(facts), status='Not run', evidence=[])
    def record(**kwargs):
        return {**copy.deepcopy(base), **kwargs}
    mc = facts.get('components', {}).get('mcp')
    state = 'Not applicable' if mc is False and not facts.get('server', {}).get('connection') else 'Not run'
    protocol = dict(protocol_version='2026-07-28', requested_era='modern', observed_era=None,
                    implementation_revision=facts['source_revision'], status=state, evidence=[])
    tools = facts.get('tools', [])
    return {
        'architecture/components.json': record(supplied=facts.get('components', {})),
        'architecture/tool-inventory.json': record(supplied_tools=tools),
        'architecture/host-matrix.json': record(hosts=[dict(host=h, status='Not run', evidence=[]) for h in facts.get('hosts', [])]),
        'readiness/requirements.json': record(requirements=requirements(facts)),
        'protocol/supported-versions.json': dict(protocol, claimed_versions=[]),
        'protocol/capability-matrix.json': dict(protocol, supplied_capabilities=facts.get('server', {}).get('required_capabilities', [])),
        'protocol/compatibility-tests.json': dict(protocol, cases=[]),
        'protocol/negotiation-results.json': dict(protocol, observations=[]),
        'tools/inventory.json': record(supplied_tools=tools, status=state),
        'tools/schemas.json': record(status=state, schemas=[{k: t[k] for k in ('name', 'inputSchema', 'outputSchema') if k in t} for t in tools]),
        'tools/cases.json': record(cases=plan['cases'], status=state), 'tools/results.json': record(results=[], status=state),
        'tools/coverage.json': record(status=state, tools=[dict(name=t['name'], status='Not run') for t in tools]),
        'security/access-matrix.json': record(permissions=facts.get('permissions', 'Unknown')),
        'security/scopes.json': record(scopes=[]), 'security/oauth-cases.json': record(cases=[]),
        'security/authorization-results.json': record(results=[]),
        'submission/metadata.json': record(supplied=facts.get('listing', {})),
        'submission/review-cases.json': record(cases=[], note='Derive current applicable cases; skills-only skips MCP review.'),
        'submission/publication-state.json': record(lifecycle='Prepared', submitted=False, approved=False, published=False),
        'publisher/facts.json': record(supplied=facts.get('publisher', {}), creator_confirmed=False),
        'testing/inspector/commands.json': record(commands=[]), 'testing/inspector/results.json': record(results=[]),
        'testing/mcpdo/commands.json': record(commands=[]), 'testing/mcpdo/results.json': record(results=[]),
        'operations/plan.json': record(monitoring_active=False, supplied=facts.get('release', {})),
    }
