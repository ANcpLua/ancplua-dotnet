---
name: prepare-plugin-submission
description: Build, repair, test, package, and maintain OpenAI plugins, skills, modern MCP v2 integrations, optional UI, and Responses API connections. Use for OpenAI ecosystem engineering, submission readiness, or explicitly selected cross-platform migration. Produce runnable changes and source-bound evidence; keep host verification, review, and publication separate.
---

# Submission Studio

Help developers contribute usable integrations to the OpenAI ecosystem. Default to
OpenAI; route to Claude or dual-platform work only when the user selects it.
Read [OpenAI lifecycle](references/openai-lifecycle.md) for the complete contract
and [shared MCP engineering](references/shared-mcp.md) for vendor-neutral protocol
work. These describe expected work, not already-passing evidence.

Carry out authorized engineering: inspect source, implement missing components,
build, execute tests, repair failures, generate review materials, package, and
read back saved state. Start with the smallest supported structure: skills for
instructions, MCP for external operations, UI only when useful. Keep working
through accessible steps if a host or credential is unavailable.

Use modern MCP (v2) for new implementation. Record SDK package versions and the
actual dated wire protocol separately: a v2 dependency alone proves no modern
negotiation. For TypeScript use the split v2 packages and SDK factories in
[SDK implementation](references/typescript-sdk.md); prefer maintained SDK APIs
in other languages too. Avoid new v1 servers, legacy SSE scaffolds, manual
JSON-RPC dispatch, or copied legacy initialization boilerplate. Inspect old
projects, propose the relevant migration, and preserve unrelated behavior.
Legacy interoperability is an explicit tested compatibility route, not the
starting point. A compatibility plugin manifest is unrelated to MCP wire era.

Open current official pages for rules that affect the work. Use OpenAI sources
for host and publication policy; MCP specification/SDK sources for protocol APIs.
If prose or referenced files cannot be retrieved, omit unsupported assertions,
record the gap, and continue. Never fabricate missing documentation. See
[source authority](references/source-authority.md) for verified conflicts and dates.

## 1. Inspect and route

Read repository instructions, manifests, skills, MCP configuration, tools,
existing listing, and prior review state. If source is missing, ask for its
location and continue from supplied materials. Never guess an endpoint,
publisher, tool capability, or saved plugin identity.

For executable workflows, read [workflow commands](references/workflows.md).
Use the bundled generator to create actual deliverables, fill the integration
record from evidence, and run the generated acceptance commands. Existing-server
preparation and optional starter creation are separate modes. Do not return
only a checklist when the requested files and tests can be produced.

Identify the requested targets; ask only if the answer changes the work:

| Target | Deliverable |
| --- | --- |
| OpenAI | Portable plugin ZIP, with any intended MCP server in its first release. |
| Claude connector | Hosted MCP endpoint, listing, authentication, and review evidence. |
| Claude plugin | GitHub plugin folder; an owned remote MCP server also needs a separate connector submission. |
| Both | Shared source with separate packages, host tests, and status records. |

Use [sources](references/sources.md) to open the current primary guide for the
selected route. Read [compatibility](references/compatibility.md) for model,
connector_id, transport, or OAuth questions. Keep server, host, package, and
API-caller compatibility separate.

When changing TypeScript MCP code, read [SDK implementation](references/typescript-sdk.md).
Resolve the installed SDK generation against the current official docs before
writing imports, migrating code, or replacing duplicated protocol plumbing.

## 2. Establish evidence and the next deliverable

Start a [readiness record](templates/readiness.md): source revision or archive
SHA-256, target, intended host surfaces, inspected files, and source URLs/dates.
Separate **Observed** facts, **Creator confirmed** intent, and **Unknown** gaps.
A supplied statement is not a test result. Reuse prior answers.

Ask at most three short questions at a time. First resolve source, target, and
access; collect identity, countries, and commerce only when that stage needs them.
Inspect existing assets first. Do not front-load a long intake questionnaire.
Continue independent drafting and fixes while waiting. Do not ask again for an
action already authorized. Do not infer legal identity or country targeting.

## 3. Prepare source and review materials

Follow [OpenAI](references/openai.md) or [Claude](references/claude.md), plus
[review evidence](references/review-evidence.md). Draft supported listing copy
and realistic example prompts from actual capabilities. Help complete missing
URLs, assets, sample data, reviewer access, and recordings; never invent them.
Keep secrets out of ZIPs, public files, screenshots, and reports. Use dedicated
sample accounts instead of a real account's private data.

A skills-only plugin does not need MCP cases, a server, OAuth, or an MCP demo.
For an MCP integration, rehearse real workflows before recording. A screenshot
or demo script is not a video recording.

Preserve source, identity, existing app bindings, and audience. Build public
uploads in a separate staging directory. Do not create a duplicate private
plugin to bypass an update restriction.

## 4. Engineer and validate in independent layers

Use `prepare_workflow.py init --platform openai` and `prepare` to generate
OpenAI architecture, protocol, security, tool, requirement, review, and operations
records from actual inspected facts. Fill them with implemented source and real
evidence, and create applicable components; an empty generated record is Not run.
The generator never supplies missing legal facts or certifies host compatibility.
For existing servers, discover the live inventory, derive fixtures and independent
expected results from source and controlled data, and generate an executable test
kit. Do not require the creator to provide completed test results.

Cover each applicable tool's valid and invalid inputs, schema boundaries,
authorization, errors, effects, deadlines and concurrency. Cover resources and
prompts when exposed; test session cleanup and security boundaries. Treat tasks,
sampling, elicitation, events, subscriptions, and UI as optional and dependent on
both protocol and host support. Modern per-request negotiation must not inherit
legacy session assumptions. Record observed output and side effects.

Keep static validation, deterministic process/SDK tests, Inspector/mcpdo tests,
agent behavior, actual ChatGPT/Codex host tests, directory review, and publication
as separate evidence layers. A skills-only plugin skips MCP-specific checks.



**Local evidence:** resolve the actual package format and selected configuration.
Portable `mcp.json` is canonical; an absent OpenAI extension can use the Codex
overlay, while a present object (including `{}`) takes precedence. Compatibility
packages can reference `.mcp.json`. An unresolved declaration is not skills-only.
Run the bundled checker on the actual finished archive:

```sh
python3 <skill-directory>/scripts/check_package.py <archive-or-folder> \
  --target openai --profile submission --json <report.json> --html <report.html>
```

Use `--target claude` for a Claude plugin. Read findings, fix the source, rebuild,
and rerun. Without Python or files, do manual inspection and mark the command
unrun. Use `--profile package` for private/local preparation; public restrictions belong
to `--profile submission`. Error findings block implemented checks; holds need
review, warnings are advisories, and unverified findings need more evidence.
Supply `--repository-root` for Claude rules outside the plugin folder.
This offline checker does not validate a connector-only submission. For an
exported tools/list response, run `scripts/inspect_tools.py inventory.json
--target openai --output tools-review.json` (or `--target claude`). Complete the
[per-tool record](templates/tool-review.md); static metadata is not execution.

**Independent evidence:** compare the result with current official docs and,
when available and authorized, native validation and Plugin Creator or directory
tooling. In Claude Code run `claude plugin validate <folder>`. Inspect the actual
installed plugin and run representative prompts in every claimed host. Record
expected/observed behavior, version, and failures using [evaluation](references/evaluation.md).
For OpenAI, do not mark functional verification complete until every submitted
review case passes on each supported surface where the integration will be
available (engineering gate; current review-case fields are in O2). Bind every result to case, surface, source revision and package
hash; a changed package requires fresh relevant evidence. Missing or blocked
runs prevent that claim while independent preparation can continue.
For Claude, compare real prompts with and without the plugin and verify loading
and behavior on each intended surface. For a connector, test every exposed tool
in MCP Inspector and real Claude; three examples do not replace tool coverage. Never infer how many tools were
tested from the number of prompts; reconcile actual tool results with the inventory.
Use [mcpdo testing](references/mcpdo.md) for workflows spanning one persistent
connection, including elicitation and supported task/subscription flows. Use
the Inspector CLI for independent single-request checks.
Apply each surface's supported-component matrix. A package scan is not a
functional test, and these guides do not establish a universal 100%-over-all-
models-and-surfaces upload rule. Tool success alone does not establish workflow
correctness.

Use screenshots of real UI where applicable: installed name, icon, starter
prompts, invocation, findings, and final handoff. Capture only relevant content;
record path and what it proves. Do not fabricate a UI or treat a report preview
as installation evidence. Missing screenshot capability leaves this unverified.

## 5. Finish the authorized handoff

Return actual artifact links, status per target, verified checks, specific gaps,
and next action. Distinguish **local checks passed**, **behavioral evaluation passed**, **live host verified**, **review
materials complete**, **draft uploaded**, **submitted**, **approved**, **published**.

Write a concrete next-action sentence in the final reply: name the needed input
or command and who can supply or run it. Include it even when it is recorded in
a linked report or `handoff.json`; a file pointer or list of missing items is
insufficient. Respect requested length limits by leaving secondary findings in
the report, while keeping the next action in the reply itself.

For ZIP-only requests, stop at the artifact. If a private installation is
requested, use Plugin Creator's current create/update contract when available:
resolve existing identity, save the archive, read back the saved files/version,
and return its plugin link. A local installation is not a cloud installation.

For authorized directory actions, follow the current guide and inspect the
saved version. Legal attestations require the creator's confirmed answers and
applicable explicit confirmation. Submission, cancelling review, public GitHub
visibility, and publication are separate actions; stay within authorization.
If access blocks one step, finish independent work and state the remaining gap.


## Lifecycle and evidence contract

Use check statuses `Passed`, `Failed`, `Blocked`, `Not run`, and `Not applicable`.
Keep lifecycle states `Prepared`, `Locally validated`, `Host verified`,
`Review-ready`, `Submitted`, `Approved`, and `Published` distinct. Every enforceable
requirement needs authority, applicability, source URL, actual retrieval date,
revision/hash, verification method, observed result, and evidence location.
An index entry is not a read page; supplied specifications are not official policy.

Maintain four separate compatibility contracts: MCP service, plugin package,
product host, and API caller. Use `server_url` for custom Responses API servers;
`connector_id` is the legacy built-in connector selector, not a server API to
implement. Verify specific API model IDs instead of promising future models.

Prepare applicable listing, review cases, reviewer access, real recordings,
security/data-flow evidence, release notes, rollout/rollback and maintenance
instructions. Category conversion specifications apply only to the selected
commerce workflow. Secrets stay in secure fields. Continuing monitoring needs
an explicitly authorized external runner; a generated runbook is not monitoring.
