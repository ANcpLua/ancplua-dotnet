# Source authority for 2.0.0

Checked on 2026-10-15. This is a per-topic retrieval record, not a claim that
all linked pages or all historical checker rules have been revalidated.
The two supplied specifications define the requested product scope; they are
not official platform policy. Missing prose and unavailable baseline records
are omitted without invented replacements.

| Source | Observed guidance | Authority and scope |
| --- | --- | --- |
| [Plugin packaging](https://developers.openai.com/plugins/build/plugins) | Portable root manifest, fixed skills/MCP paths, OpenAI extension and compatibility fallback. | Official package guidance. |
| [Submit](https://developers.openai.com/plugins/deploy/submission) | Remote MCP initial review uses five positive and three negative cases and a real demo; skills-only is exempt. Upload, review and publication are separate. | Official submission requirements, conditional on route. |
| [Remote review](https://developers.openai.com/plugins/deploy/app-review) | Public endpoint, verified identity, review access; annotations reflect actual server behavior. | Official remote MCP review guidance. |
| [OpenAI server tutorial](https://developers.openai.com/plugins/build/mcp-server) | The retrieved tutorial still uses monolithic TypeScript SDK imports. | Host engineering guide with a generation conflict; do not copy its v1 imports into a v2 project. |
| [MCP SDK v2](https://ts.sdk.modelcontextprotocol.io/v2/) | Split client/server packages are the stable v2 line for the 2026-07-28 specification. | Official TypeScript implementation authority. |
| [Protocol support](https://ts.sdk.modelcontextprotocol.io/v2/migration/support-2026-07-28.html) | Hand-constructed clients default to legacy; modern pinning and SDK serving factories are explicit. | Official SDK negotiation guidance; SDK version alone does not establish wire era. |
| [MCP specification](https://modelcontextprotocol.io/specification/2026-07-28) | Modern core is stateless with per-request capabilities. | Protocol authority, not host-support evidence. |
| [mcpdo](https://modelcontextprotocol.io/docs/2026-07-28/tools/inspector/mcpdo) | Named agent calls, bare JSON payloads, parked auth/elicitation, tasks, explicit era and automatic daemon. | Experimental client guidance; installed help governs available commands. |
| [Inspector security](https://modelcontextprotocol.io/docs/2026-07-28/tools/inspector/security) and [configuration](https://modelcontextprotocol.io/docs/2026-07-28/tools/inspector/configuration) | Stdio process privileges, private daemon limits, cross-process secret storage. | Tool-specific operational guidance. |
| [Responses MCP](https://developers.openai.com/api/docs/guides/tools-connectors-mcp) | Custom remote servers use server_url. Built-in connector_id has the documented model-date deprecation. | API caller contract, distinct from product host support. |

Prefer protocol/SDK sources for modern implementation APIs and OpenAI sources
for OpenAI host policy. Record conflicting examples instead of declaring all
OpenAI hosts modern-compatible. Test each claimed environment.

Historical offline checker findings retain their original source dates. Reopen
the relevant primary page before enforcing one as a current official rule.
Generated OpenAI requirement records are suggested engineering checks with
`source_checked_at: null` until the acting agent actually verifies that rule.
They must not be promoted to official requirements just because a URL exists.

No reference to a 1.5.0 evaluation baseline establishes prior validation: the
editable installed release was 1.2.1, and that unavailable baseline was omitted.
