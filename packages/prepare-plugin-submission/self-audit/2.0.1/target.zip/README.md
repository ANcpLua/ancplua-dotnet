# Submission Studio 2.0.1

Build, repair, test, package, and prepare integrations for the OpenAI ecosystem.
OpenAI is the default; cross-platform migration is available when selected.

The agent uses the supplied [OpenAI lifecycle](skills/prepare-plugin-submission/references/openai-lifecycle.md)
and [shared MCP contract](skills/prepare-plugin-submission/references/shared-mcp.md),
checks current official sources, and completes engineering work with available
file, terminal, browser, and account tools. New MCP projects use modern v2 SDK
APIs. Protocol version, package format and host support are recorded separately.

Included: an offline Python 3.10+ package checker, platform-aware preparation
packs, a locked TypeScript v2 starter, SDK/Inspector/experimental mcpdo test kits,
source authority records, and evaluation cases. Generated test kits need Node
22.19+ and `npm ci`. See [commands](skills/prepare-plugin-submission/references/workflows.md).

Start with source inspection and a live inventory for MCP, then generate a pack:

```sh
python3 <skill>/scripts/prepare_workflow.py init --id my-plugin --platform openai --output integration.json
python3 <skill>/scripts/prepare_workflow.py prepare --input integration.json --output submission-pack
```

Fill the input from inspected source and discovery before generating executable
fixtures. The generator initializes records; the agent implements missing work
and runs checks. Blank records, supplied claims and offline checks never prove
host compatibility, OAuth completeness, directory approval, or publication.

Starter prompts focus on OpenAI. Existing identity, author, icon and private
audience are preserved; cross-platform workflows remain available when selected. No backend, credentials, active monitoring,
legal attestation, or public directory action is supplied by installation.
